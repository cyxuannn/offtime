const activities = [
  "Go for a 15 minute walk and write down 3 things you noticed.",
  "Ask a friend about a childhood memory they love. Write down what you want to remember about them!",
  "Write a note of appreciation for someone who helped you recently.",
  "Sit outside and list 3 sounds you hear."
];

let points = 0;
let timerInterval = null; //countdown
let remainingSeconds = 0;

//generate activity
document.getElementById("generate").addEventListener("click", () => {
  const random = activities[Math.floor(Math.random() * activities.length)];
  document.getElementById("activity").textContent = random;
});

//add pionts once reflection is submitted, or remind to add reflection
document.getElementById("submit").addEventListener("click", () => {
  const reflection = document.getElementById("reflection").value.trim();
  if (reflection) {
    points += 10;
    document.getElementById("points").textContent = `You’ve earned ${points} scroll minutes 🌞`;
    document.getElementById("reflection").value = "";
    document.getElementById("activity").textContent = "";
  } else {
    alert("complete the activity first!");
  }
});

// when user clicks "Start Social Time"
document.getElementById("startSocial").addEventListener("click", () => {
  if (points <= 0) {
    alert("You haven’t earned any social time yet!");
    return;
  }

  // convert points to seconds
  remainingSeconds = points * 60;

  // reset points
  points = 0;
  document.getElementById("points").textContent = `You’ve earned 0 mindful minutes 🌞`;

  // store allowance in chrome storage
  if (chrome && chrome.storage) {
    const allowedUntil = Date.now() + remainingSeconds * 1000;
    chrome.storage.local.set({ allowedUntil: allowedUntil });
  }

  updateTimerDisplay();

  timerInterval = setInterval(() => {
    remainingSeconds--;
    if (remainingSeconds <= 0) {
      clearInterval(timerInterval);
      timerInterval = null;
      document.getElementById("timer").textContent = "⏰ Time’s up! Take a break 🌿";
    }
    updateTimerDisplay();
  }, 1000);
});
