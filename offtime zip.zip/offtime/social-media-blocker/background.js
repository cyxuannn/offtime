// list of blocked sites
const blockedSites = ["instagram.com", "facebook.com", "twitter.com", "tiktok.com", "reddit.com"];

// listen when a tab navigates
chrome.webNavigation.onCommitted.addListener(async (details) => {
  const url = details.url;
  const now = Date.now();

  // check allowance from storage
  chrome.storage.local.get(["allowedUntil"], (result) => {
    const allowedUntil = result.allowedUntil || 0;

    // if time expired and URL matches blocked sites, redirect to blocked.html
    if (now > allowedUntil && blockedSites.some(site => url.includes(site))) {
      chrome.tabs.update(details.tabId, { url: chrome.runtime.getURL("blocked.html") });
    }
  });
});
